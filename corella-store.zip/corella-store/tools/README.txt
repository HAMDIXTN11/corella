Corella Store Theme - Assets Guidance

- Replace assets/images/hero.jpg with a 1600x900 lifestyle hero (black & white aesthetic, diverse models).
- Replace assets/images/cat-men.jpg, cat-women.jpg, cat-accessories.jpg with 1000x1250 category images.
- Add product images under WooCommerce Products. Use JPG 1600px on long edge, quality 82.
- Screenshot: replace screenshot.png with a 1200x900 PNG of the homepage.

Note: Ensure you own the rights to any images. Avoid trademarked logos on apparel. Prefer your own photos or properly licensed stock.