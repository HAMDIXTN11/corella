<?php
/** Front Page template */
if (!defined('ABSPATH')) { exit; }
require locate_template('home.php');