const bizSdk = require('facebook-nodejs-business-sdk');
const FacebookAdsApi = bizSdk.FacebookAdsApi;
const AdAccount = bizSdk.AdAccount;
const Campaign = bizSdk.Campaign;
const AdSet = bizSdk.AdSet;
const AdCreative = bizSdk.AdCreative;
const Ad = bizSdk.Ad;

// Helpers
function corsify(body, statusCode=200) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-FB-Token",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
    },
    body: JSON.stringify(body)
  };
}
function requireAuth(event) {
  const token = process.env.ADMIN_TOKEN;
  if (!token) return; // disabled
  const hdr = (event.headers && (event.headers.authorization || event.headers.Authorization)) || "";
  const ok = hdr.startsWith("Bearer ") && hdr.slice(7) === token;
  if (!ok) { const e = new Error("Unauthorized"); e.statusCode = 401; throw e; }
}
function minorOffsetForCurrency(cur) {
  const three = new Set(["BHD","JOD","KWD","OMR","TND","IQD"]);
  return three.has((cur||'').toUpperCase()) ? 1000 : 100;
}
function tndToMinor(x, offset) { return Math.round(x * offset); }
function minorToTnd(x, offset) { return x / offset; }


async function ensureCampaign(name, objective, adAccountId) {
  const acc = new AdAccount(adAccountId);
  const camps = await acc.getCampaigns(['id','name'], { effective_status: ['ACTIVE','PAUSED'] });
  const found = camps.find(c => c.name === name);
  if (found) return found.id;
  const camp = await acc.createCampaign({
    name, objective, status: 'PAUSED', buying_type: 'AUCTION', special_ad_categories: []
  });
  return camp.id;
}

async function ensureAdSet(name, campaignId, dailyMinor, optimization_goal, adAccountId, pageId) {
  const sets = await (new Campaign(campaignId)).getAdSets(['id','name','campaign_id'], { effective_status: ['ACTIVE','PAUSED'] });
  const found = sets.find(s => s.name === name);
  if (found) {
    await (new AdSet(found.id)).update({ daily_budget: dailyMinor });
    return found.id;
  }
  const adset = await (new AdAccount(adAccountId)).createAdSet({
    name,
    campaign_id: campaignId,
    daily_budget: dailyMinor,
    billing_event: 'IMPRESSIONS',
    optimization_goal,
    bid_strategy: 'LOWEST_COST_WITHOUT_CAP',
    status: 'PAUSED',
    promoted_object: { page_id: pageId },
    targeting: {
      age_min: 18, age_max: 45,
      geo_locations: { countries: ['TN'] },
      publisher_platforms: ['facebook','instagram'],
      facebook_positions: ['feed','marketplace','video_feeds','stories','reels'],
      instagram_positions: ['stream','story','reels']
    }
  });
  return adset.id;
}

async function createEngagementAds(adsetId, pagePostIds, adAccountId) {
  const acc = new AdAccount(adAccountId);
  const adIds = [];
  for (let i=0;i<pagePostIds.length;i++) {
    const ppid = pagePostIds[i];
    const cr = await acc.createAdCreative({
      name: `Boost | Post ${i+1}`,
      object_story_id: ppid
    });
    const ad = await acc.createAd({
      name: `Boost | Post ${i+1}`,
      adset_id: adsetId,
      creative: { creative_id: cr.id },
      status: 'PAUSED'
    });
    adIds.push(ad.id);
  }
  return adIds;
}

async function ensureMsgCreative(adAccountId, pageId, whatsapp) {
  const acc = new AdAccount(adAccountId);
  const wanted = "CTWA | Hero Creative";
  const list = await acc.getAdCreatives(['id','name'], { limit: 100 });
  const found = list.find(c => c.name === wanted);
  if (found) return found.id;
  const creative = await acc.createAdCreative({
    name: wanted,
    object_story_spec: {
      page_id: pageId,
      link_data: {
        link: `https://wa.me/${whatsapp}`,
        message: "Corella Store – كلمنا على واتساب باش نحجزولك العرض والمقاس 👇",
        call_to_action: {
          type: "WHATSAPP_MESSAGE",
          value: { link: `https://wa.me/${whatsapp}` }
        }
      }
    }
  });
  return creative.id;
}

async function ensureMsgAd(adsetId, creativeId, adAccountId) {
  const acc = new AdAccount(adAccountId);
  const ads = await acc.getAds(['id','name','adset_id'], { effective_status: ['ACTIVE','PAUSED'] });
  const found = ads.find(a => a.name === "CTWA | Ad 1" && a.adset_id === adsetId);
  if (found) return found.id;
  const ad = await acc.createAd({
    name: "CTWA | Ad 1",
    adset_id: adsetId,
    creative: { creative_id: creativeId },
    status: 'PAUSED'
  });
  return ad.id;
}

async function activateAll(campId, adsetId, adIds) {
  await (new Campaign(campId)).update({ status: 'ACTIVE' });
  await (new AdSet(adsetId)).update({ status: 'ACTIVE' });
  for (const aid of adIds) { await (new Ad(aid)).update({ status: 'ACTIVE' }); }
}

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return corsify({ ok: true });
  try {
    requireAuth(event);
    const fbToken = (event.headers && (event.headers['x-fb-token'] || event.headers['X-FB-Token'])) || process.env.FB_ACCESS_TOKEN;
    if (!fbToken) throw new Error("Missing Facebook token (header X-FB-Token or FB_ACCESS_TOKEN).");
    const body = JSON.parse(event.body || "{}");

    const AD_ACCOUNT_ID = (event.queryStringParameters && event.queryStringParameters.ad_account_id) || body.ad_account_id || process.env.AD_ACCOUNT_ID;
    const PAGE_ID = (event.queryStringParameters && event.queryStringParameters.page_id) || body.page_id || process.env.PAGE_ID;
    const WHATSAPP = body.whatsapp_number || process.env.WHATSAPP_NUMBER;
    if (!AD_ACCOUNT_ID) throw new Error("Missing ad_account_id.");
    if (!PAGE_ID) throw new Error("Missing page_id.");
    if (!WHATSAPP) throw new Error("Missing whatsapp_number.");

    FacebookAdsApi.init(fbToken);

    const accInfo = await (new AdAccount(AD_ACCOUNT_ID)).get([ "currency" ]);
    const offset = minorOffsetForCurrency(accInfo.currency || "TND");

    let posts = Array.isArray(body.posts) ? body.posts : [];
    posts = posts.map(pid => pid.includes("_") ? pid : `${PAGE_ID}_${pid}`);

    // Engagement
    const engCampaign = await ensureCampaign(`${process.env.BRAND || 'Corella Store'} | Engagement`, "ENGAGEMENT", AD_ACCOUNT_ID);
    const engAdSet = await ensureAdSet("TN | 18-45 | FB+IG | Boost", engCampaign, tndToMinor(parseFloat(body.eng_min || 10), offset), "POST_ENGAGEMENT", AD_ACCOUNT_ID, PAGE_ID);
    const engAds = await createEngagementAds(engAdSet, posts, AD_ACCOUNT_ID);
    await activateAll(engCampaign, engAdSet, engAds);

    // Messages
    const msgCampaign = await ensureCampaign(`${process.env.BRAND || 'Corella Store'} | CTWA | Sales`, "MESSAGES", AD_ACCOUNT_ID);
    const msgAdSet = await ensureAdSet("TN | 18-45 | FB+IG | Messages", msgCampaign, tndToMinor(parseFloat(body.msg_min || 10), offset), "MESSAGING_CONVERSATIONS", AD_ACCOUNT_ID, PAGE_ID);
    const msgCreative = await ensureMsgCreative(AD_ACCOUNT_ID, PAGE_ID, WHATSAPP);
    const msgAd = await ensureMsgAd(msgAdSet, msgCreative, AD_ACCOUNT_ID);
    await activateAll(msgCampaign, msgAdSet, [msgAd]);

    return corsify({
      ok: true,
      offset,
      engagement: { campaign_id: engCampaign, adset_id: engAdSet, ads: engAds },
      messages:   { campaign_id: msgCampaign, adset_id: msgAdSet, ad_id: msgAd }
    });
  } catch (err) {
    return corsify({ error: err.message || String(err) }, err.statusCode || 500);
  }
};
